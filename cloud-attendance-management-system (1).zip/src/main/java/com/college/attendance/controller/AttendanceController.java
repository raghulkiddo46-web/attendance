package com.college.attendance.controller;

import com.college.attendance.model.Attendance;
import com.college.attendance.model.Student;
import com.college.attendance.repository.AttendanceRepository;
import com.college.attendance.repository.StudentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/attendance")
@CrossOrigin
public class AttendanceController {
    private final AttendanceRepository attendance;
    private final StudentRepository students;
    public AttendanceController(AttendanceRepository attendance, StudentRepository students) {
        this.attendance = attendance; this.students = students;
    }
    public record AttendanceRequest(Long studentId, LocalDate date, Attendance.Status status) {}

    @PostMapping public Attendance mark(@RequestBody AttendanceRequest request) {
        if (request.studentId() == null || request.date() == null || request.status() == null)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "studentId, date and status are required");
        Student student = students.findById(request.studentId())
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Student not found"));
        if (attendance.existsByStudentIdAndAttendanceDate(student.getId(), request.date()))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Attendance already marked for this date");
        return attendance.save(new Attendance(student, request.date(), request.status()));
    }
    @GetMapping public List<Attendance> byDate(@RequestParam(required = false) LocalDate date) {
        return attendance.findByAttendanceDate(date == null ? LocalDate.now() : date);
    }
    @GetMapping("/student/{id}") public List<Attendance> byStudent(@PathVariable Long id) {
        return attendance.findByStudentIdOrderByAttendanceDateDesc(id);
    }
}
