package com.college.attendance.controller;

import com.college.attendance.model.Student;
import com.college.attendance.repository.StudentRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@RestController
@RequestMapping("/api/students")
@CrossOrigin
public class StudentController {
    private final StudentRepository students;
    public StudentController(StudentRepository students) { this.students = students; }

    @GetMapping public List<Student> all() { return students.findAll(); }
    @PostMapping public Student create(@Valid @RequestBody Student student) {
        students.findByRollNumber(student.getRollNumber()).ifPresent(s -> {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Roll number already exists");
        });
        return students.save(student);
    }
    @GetMapping("/{id}") public Student one(@PathVariable Long id) {
        return students.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id) { students.deleteById(id); }
}
