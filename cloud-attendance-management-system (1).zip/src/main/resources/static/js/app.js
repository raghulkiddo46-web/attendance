const API = '/api';
const today = new Date().toISOString().slice(0,10);
document.getElementById('attendanceDate').value = today;
document.getElementById('reportDate').value = today;

async function request(url, options={}) {
  const response = await fetch(url, {headers:{'Content-Type':'application/json'}, ...options});
  if (!response.ok) {
    let message = `Request failed (${response.status})`;
    try { const body = await response.json(); message = body.message || body.detail || message; } catch {}
    throw new Error(message);
  }
  if (response.status === 204) return null;
  return response.json();
}
function showMessage(id, text, error=false) {
  const el = document.getElementById(id); el.textContent = text;
  el.className = error ? 'message error' : 'message';
}
async function loadStudents() {
  const students = await request(`${API}/students`);
  document.getElementById('totalStudents').textContent = students.length;
  const select = document.getElementById('studentSelect');
  select.innerHTML = '<option value="">Select student</option>';
  const rows = document.getElementById('studentRows'); rows.innerHTML = '';
  students.forEach(s => {
    const option = document.createElement('option'); option.value = s.id;
    option.textContent = `${s.rollNumber} — ${s.name}`; select.appendChild(option);
    const tr = document.createElement('tr');
    [s.rollNumber,s.name,s.department || '—',s.email || '—'].forEach(v => {
      const td = document.createElement('td'); td.textContent = v; tr.appendChild(td);
    });
    rows.appendChild(tr);
  });
}
async function loadAttendance() {
  const date = document.getElementById('reportDate').value || today;
  const records = await request(`${API}/attendance?date=${date}`);
  const rows = document.getElementById('attendanceRows'); rows.innerHTML = '';
  let present=0, absent=0;
  records.forEach(a => {
    if (a.status === 'PRESENT') present++;
    if (a.status === 'ABSENT') absent++;
    const tr = document.createElement('tr');
    [a.student.rollNumber,a.student.name,a.attendanceDate,a.status].forEach(v => {
      const td = document.createElement('td'); td.textContent = v; tr.appendChild(td);
    });
    rows.appendChild(tr);
  });
  document.getElementById('presentToday').textContent = present;
  document.getElementById('absentToday').textContent = absent;
}
document.getElementById('studentForm').addEventListener('submit', async e => {
  e.preventDefault(); const data = Object.fromEntries(new FormData(e.target).entries());
  try { await request(`${API}/students`, {method:'POST',body:JSON.stringify(data)});
    e.target.reset(); showMessage('studentMessage','Student added successfully.'); await loadStudents();
  } catch(err) { showMessage('studentMessage',err.message,true); }
});
document.getElementById('attendanceForm').addEventListener('submit', async e => {
  e.preventDefault();
  const payload = {studentId:Number(document.getElementById('studentSelect').value),
    date:document.getElementById('attendanceDate').value,
    status:document.getElementById('attendanceStatus').value};
  try { await request(`${API}/attendance`,{method:'POST',body:JSON.stringify(payload)});
    showMessage('attendanceMessage','Attendance saved successfully.');
    document.getElementById('reportDate').value = payload.date; await loadAttendance();
  } catch(err) { showMessage('attendanceMessage',err.message,true); }
});
document.getElementById('reportDate').addEventListener('change',()=>loadAttendance().catch(console.error));
document.getElementById('refreshButton').addEventListener('click',()=>refresh().catch(console.error));
async function refresh(){await loadStudents();await loadAttendance();}
refresh().catch(err=>alert(`Could not load data: ${err.message}`));
