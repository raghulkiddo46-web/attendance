# Cloud-Based Attendance Management System

A college-level starter project using Java 17, Spring Boot, MySQL, Thymeleaf, HTML, CSS and JavaScript.

## Features
- Add and list students (roll number, name, department, email)
- Mark daily attendance as PRESENT, ABSENT or LATE
- Prevent duplicate attendance for the same student and date
- View attendance by date and view a student's attendance history through the API
- Dashboard totals for students, present and absent records for the selected report date

## Requirements
- JDK 17+
- Maven 3.8+
- MySQL 8+

## Setup
1. Create a MySQL user/database, or use a local MySQL root account.
2. Open `src/main/resources/application.properties` and replace `CHANGE_ME` with your MySQL password. Update username/URL if needed.
3. From this project folder run:

   ```bash
   mvn spring-boot:run
   ```

4. Open http://localhost:8080

Hibernate creates the tables automatically on first start (`ddl-auto=update`).

## REST API
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/students` | List students |
| POST | `/api/students` | Create student |
| GET | `/api/students/{id}` | Get one student |
| DELETE | `/api/students/{id}` | Delete student |
| POST | `/api/attendance` | Mark attendance |
| GET | `/api/attendance?date=YYYY-MM-DD` | Attendance for a date (today if omitted) |
| GET | `/api/attendance/student/{id}` | Student attendance history |

### Example requests

Create a student:
```json
{"rollNumber":"CS001","name":"Arun Kumar","department":"CSE","email":"arun@example.com"}
```

Mark attendance:
```json
{"studentId":1,"date":"2026-10-30","status":"PRESENT"}
```

## Important notes
- This is an academic starter implementation, not a production-ready deployment. Add authentication/authorization, role management, CSRF protection, audit logs, pagination, backups and HTTPS before real institutional use.
- The current UI is intended for a trusted local/demo environment. Do not expose it publicly without securing the application.
- Attendance uniqueness is enforced at database level for each student/date.
